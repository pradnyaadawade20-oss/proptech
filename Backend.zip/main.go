﻿package main

import (
	"log"
	"net/http"

	"context"

	"proptech-backend/internal/config"
	"proptech-backend/internal/handlers"
	"proptech-backend/internal/mail"
	"proptech-backend/internal/migrate"
	"proptech-backend/internal/notify"
	"proptech-backend/internal/push"
	"proptech-backend/internal/repository"
	"proptech-backend/internal/routes"
	"proptech-backend/migrations"

	"github.com/gin-gonic/gin"
)

func main() {
	config.LoadDotEnv()

	cfg := config.LoadConfig()
	log.Println("Email OTP:", cfg.EmailTransport())
	if cfg.DevSkipOTP {
		log.Println("WARNING: DEV_SKIP_OTP=true — OTP verification can be skipped. Turn this off before real users sign up.")
	}

	dbPool, err := config.NewDBPool(cfg)
	if err != nil {
		log.Fatal("Failed to connect to database:", err)
	}
	defer dbPool.Close()

	log.Println("Connected to database successfully")

	if err := migrate.Run(context.Background(), dbPool, migrations.Files); err != nil {
		log.Fatal("Failed to run migrations:", err)
	}
	log.Println("Migrations up to date")

	propertyRepo := repository.NewPropertyRepository(dbPool)
	propertyHandler := handlers.NewPropertyHandler(propertyRepo)

	userRepo := repository.NewUserRepository(dbPool)
	otpRepo := repository.NewEmailOTPRepository(dbPool)
	mailer := mail.New(mail.Config{
		Host:        cfg.SMTPHost,
		Port:        cfg.SMTPPort,
		Username:    cfg.SMTPUser,
		Password:    cfg.SMTPPass,
		BrevoAPIKey: cfg.BrevoAPIKey,
		FromEmail:   cfg.EmailFrom,
		FromName:    cfg.EmailName,
		DevLogOTP:   cfg.DevLogOTP,
	})
	authHandler := handlers.NewAuthHandler(userRepo, otpRepo, mailer, cfg.DevSkipOTP)
	profileHandler := handlers.NewProfileHandler(userRepo)

	favoriteRepo := repository.NewFavoriteRepository(dbPool)
	favoriteHandler := handlers.NewFavoriteHandler(favoriteRepo)

	visitRepo := repository.NewVisitRepository(dbPool)
	visitHandler := handlers.NewVisitHandler(visitRepo, propertyRepo)

	messageRepo := repository.NewMessageRepository(dbPool)
	messageHandler := handlers.NewMessageHandler(messageRepo)

	agreementRepo := repository.NewAgreementRepository(dbPool)
	agreementHandler := handlers.NewAgreementHandler(agreementRepo)

	brokerSubscriptionRepo := repository.NewBrokerSubscriptionRepository(dbPool)
	brokerHandler := handlers.NewBrokerHandler(brokerSubscriptionRepo)

	notificationRepo := repository.NewNotificationRepository(dbPool)
	deviceTokenRepo := repository.NewDeviceTokenRepository(dbPool)

	pushSender, err := push.NewSender(context.Background(), cfg.FirebaseCredentials)
	if err != nil {
		log.Println("Push notifications disabled — Firebase not configured:", err)
		pushSender = nil
	}
	notificationHandler := handlers.NewNotificationHandler(notificationRepo, deviceTokenRepo, pushSender)
	deviceTokenHandler := handlers.NewDeviceTokenHandler(deviceTokenRepo)

	// Auto notifications (chat, visits, agreements, listings, login) use this.
	notify.Init(dbPool, notificationRepo, deviceTokenRepo, pushSender)

	router := gin.Default()

	router.GET("/health", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{
			"status":  "ok",
			"message": "PropTech backend is running",
			"build":   "google-auth-v1",
		})
	})

	routes.RegisterPropertyRoutes(router, propertyHandler)
	routes.RegisterAuthRoutes(router, authHandler)
	routes.RegisterFavoriteRoutes(router, favoriteHandler)
	routes.RegisterVisitRoutes(router, visitHandler)
	routes.RegisterMessageRoutes(router, messageHandler)
	routes.RegisterProfileRoutes(router, profileHandler)
	routes.RegisterAgreementRoutes(router, agreementHandler)
	routes.RegisterBrokerRoutes(router, brokerHandler)
	routes.RegisterNotificationRoutes(router, notificationHandler)
	routes.RegisterDeviceTokenRoutes(router, deviceTokenHandler)

	log.Println("Server starting on port " + cfg.Port + "...")
	if err := router.Run(":" + cfg.Port); err != nil {
		log.Fatal("Failed to start server:", err)
	}
}