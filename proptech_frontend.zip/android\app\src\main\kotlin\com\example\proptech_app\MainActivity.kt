package com.example.proptech_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
